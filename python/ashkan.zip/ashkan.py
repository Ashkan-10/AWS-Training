def print_arr(array):
    for item in array:
        print(item)
arr=["saeid","ashkan","shahriar"]
print_arr(arr)